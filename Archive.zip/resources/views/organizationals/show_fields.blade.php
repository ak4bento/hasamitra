<!-- Id Company Field -->
<div class="col-sm-12">
    {!! Form::label('id_company', 'Id Company:') !!}
    <p>{{ $organizational->id_company }}</p>
</div>

<!-- Id Department Field -->
<div class="col-sm-12">
    {!! Form::label('id_department', 'Id Department:') !!}
    <p>{{ $organizational->id_department }}</p>
</div>

<!-- Job Title Field -->
<div class="col-sm-12">
    {!! Form::label('job_title', 'Job Title:') !!}
    <p>{{ $organizational->job_title }}</p>
</div>

<!-- Id Manager Org Field -->
<div class="col-sm-12">
    {!! Form::label('id_manager_org', 'Id Manager Org:') !!}
    <p>{{ $organizational->id_manager_org }}</p>
</div>

