<!-- Id Employee Field -->
<div class="col-sm-12">
    {!! Form::label('id_employee', 'Id Employee:') !!}
    <p>{{ $submission->id_employee }}</p>
</div>

<!-- Id Saldo Cuti Field -->
<div class="col-sm-12">
    {!! Form::label('id_saldo_cuti', 'Id Saldo Cuti:') !!}
    <p>{{ $submission->id_saldo_cuti }}</p>
</div>

<!-- Id Employee Approv Field -->
<div class="col-sm-12">
    {!! Form::label('id_employee_approv', 'Id Employee Approv:') !!}
    <p>{{ $submission->id_employee_approv }}</p>
</div>

<!-- Status Approv Field -->
<div class="col-sm-12">
    {!! Form::label('status_approv', 'Status Approv:') !!}
    <p>{{ $submission->status_approv }}</p>
</div>

<!-- Ket Cuti Field -->
<div class="col-sm-12">
    {!! Form::label('ket_cuti', 'Ket Cuti:') !!}
    <p>{{ $submission->ket_cuti }}</p>
</div>

<!-- Saldo Cuti Field -->
<div class="col-sm-12">
    {!! Form::label('saldo_cuti', 'Saldo Cuti:') !!}
    <p>{{ $submission->saldo_cuti }}</p>
</div>

<!-- Submission Date Field -->
<div class="col-sm-12">
    {!! Form::label('submission_date', 'Submission Date:') !!}
    <p>{{ $submission->submission_date }}</p>
</div>

