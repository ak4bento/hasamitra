<!-- Department Field -->
<div class="col-sm-12">
    {!! Form::label('department', 'Department:') !!}
    <p>{{ $department->department }}</p>
</div>

