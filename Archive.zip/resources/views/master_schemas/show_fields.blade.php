<!-- Id Department Field -->
<div class="col-sm-12">
    {!! Form::label('id_department', 'Id Department:') !!}
    <p>{{ $masterSchema->id_department }}</p>
</div>

<!-- Initial Schema Field -->
<div class="col-sm-12">
    {!! Form::label('initial_schema', 'Initial Schema:') !!}
    <p>{{ $masterSchema->initial_schema }}</p>
</div>

