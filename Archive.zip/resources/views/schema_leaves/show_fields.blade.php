<!-- Id Master Schema Field -->
<div class="col-sm-12">
    {!! Form::label('id_master_schema', 'Id Master Schema:') !!}
    <p>{{ $schemaLeave->id_master_schema }}</p>
</div>

<!-- Gender Field -->
<div class="col-sm-12">
    {!! Form::label('gender', 'Gender:') !!}
    <p>{{ $schemaLeave->gender }}</p>
</div>

<!-- Info Field -->
<div class="col-sm-12">
    {!! Form::label('info', 'Info:') !!}
    <p>{{ $schemaLeave->info }}</p>
</div>

<!-- Quantify Saldo Field -->
<div class="col-sm-12">
    {!! Form::label('quantify_saldo', 'Quantify Saldo:') !!}
    <p>{{ $schemaLeave->quantify_saldo }}</p>
</div>

<!-- Saldo Field -->
<div class="col-sm-12">
    {!! Form::label('saldo', 'Saldo:') !!}
    <p>{{ $schemaLeave->saldo }}</p>
</div>

