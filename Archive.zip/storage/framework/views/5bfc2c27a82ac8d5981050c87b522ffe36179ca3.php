<div class="table-responsive">
    <table class="table" id="example2">
        <thead>
        <tr>
            <th>No</th>
            <th>Department</th>
            <th>Job Title</th>
            <th>Manager</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php ($count = 1); ?>
        <?php $__currentLoopData = $organizationals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organizational): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($count++); ?></td>
                <td><?php echo e(App\Models\Department::find($organizational->id_department)->department); ?></td>
                <td><?php echo e($organizational->job_title); ?></td>
                <td><?php echo e(App\Models\Organizational::find($organizational->id_manager_org)->job_title ?? ''); ?></td>
                <td width="120">
                    <div class='btn-group'>
                        <a href="<?php echo e(route('organizationals.edit', [$organizational->id])); ?>"
                        class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                    </div>
                    <div class='btn-group'>
                        <?php echo Form::open(['route' => ['organizationals.destroy', $organizational->id], 'method' => 'delete']); ?>

                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                        <?php echo Form::close(); ?>

                    </div>
                    <div class='btn-group'>
                        <button id="btnSelect" class="btn <?php echo e($organizational->total_employee == 0 ? 'btn-warning disabled' : 'btn-primary'); ?> btn-xs" data-toggle="modal" data-target="#modal-lg" data-selector="<?php echo e($organizational->id); ?>" onclick="clickFunction(<?php echo e($organizational->id); ?>)"><i class="fa fa-user"></i> List <?php echo e($organizational->total_employee); ?></button>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="modal-lg">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title">List Employee</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <table id="table-employee" class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIK</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="tbodyModal">
                    <tr>
                        <td></td>
                        <td></td>
                        <td>
                            <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal"><i class="fa fa-eye"></i> Show</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/organizationals/table.blade.php ENDPATH**/ ?>