<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Hasamitra - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="https://admin.hasamitra-hrd.com/logo.ico" rel="icon">
  <link href="https://admin.hasamitra-hrd.com/logo.ico" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="landingpage/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="landingpage/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="landingpage/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="landingpage/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="landingpage/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="landingpage/assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: TheEvent - v4.7.0
  * Template URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center ">
    <div class="container-fluid container-xxl d-flex align-items-center">

      <div id="logo" class="me-auto">
        <!-- Uncomment below if you prefer to use a text logo -->
        <!-- <h1><a href="index.html">The<span>Event</span></a></h1>-->
        <a href="/" class="scrollto"><img src="/logo-full.png" alt="" title="">
            
        </a>
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      <a class="buy-tickets scrollto" href="<?php echo e(url('/login')); ?>">Login</a>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container" data-aos="zoom-in" data-aos-delay="100">
      <h1 class="mb-4 pb-0">Selamat Datang di Website<br><span>Hasamitra HRD</span></h1>
      
      <a href="https://www.youtube.com/watch?v=eepgONz_1ng" class="glightbox play-btn mb-4"></a>
      
    </div>
  </section><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    
    <!-- End About Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          

          

          

          

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>Ciber.ISCS</strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="https://akil.co.id/">ciber.iscs</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="landingpage/assets/vendor/aos/aos.js"></script>
  <script src="landingpage/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="landingpage/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="landingpage/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="landingpage/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="landingpage/assets/js/main.js"></script>

</body>

</html><?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/welcome.blade.php ENDPATH**/ ?>