<div class="table-responsive">
    <table class="table" id="example2">
        <thead>
        <tr>
            
            <th>Gender</th>
            <th>Info</th>
            <th>Quantify Saldo</th>
            <th>Saldo</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $schemaBreaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schemaBreak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php if($schemaBreak->gender == 'X'): ?> Semua <?php elseif($schemaBreak->gender == 'L'): ?> Laki-laki <?php elseif($schemaBreak->gender == 'P'): ?> Perempuan <?php endif; ?></td>
                <td><?php echo e($schemaBreak->info); ?></td>
                <td><?php echo e($schemaBreak->quantify_saldo == 'D' ? 'Hari' : 'Jam'); ?></td>
                <td><?php echo e($schemaBreak->saldo); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['schemaBreaks.destroy', $schemaBreak->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('schemaBreaks.show', [$schemaBreak->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('schemaBreaks.edit', [$schemaBreak->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/schema_breaks/table.blade.php ENDPATH**/ ?>