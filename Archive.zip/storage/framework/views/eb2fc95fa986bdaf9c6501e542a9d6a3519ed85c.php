<!-- Id Master Schema Field -->


<!-- Gender Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('gender', 'Type Gender:'); ?>

    
    <select name="gender" class="form-control">
        <option value="X">Semua</option>
        <option value="L">Laki-laki</option>
        <option value="P">Perempuan</option>
    </select>
</div>

<!-- Info Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('info', 'Info:'); ?>

    <?php echo Form::text('info', null, ['class' => 'form-control','maxlength' => 64,'maxlength' => 64]); ?>

</div>

<!-- Quantify Saldo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('quantify_saldo', 'Quantify Saldo:'); ?>

    
    <select name="quantify_saldo" class="form-control">
        <option value="">--Pilih--</option>
        <option value="D">Hari</option>
        <option value="H">Jam</option>
    </select>
</div>

<!-- Saldo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('saldo', 'Saldo:'); ?>

    <?php echo Form::number('saldo', null, ['class' => 'form-control', 'min' => '1', 'max' => '100']); ?>

</div><?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/schema_breaks/fields.blade.php ENDPATH**/ ?>