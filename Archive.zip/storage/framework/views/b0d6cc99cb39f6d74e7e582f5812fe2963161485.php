<li class="nav-header">Home</li>
<li class="nav-item">
    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>
            Dashboard
        </p>
    </a>
</li>

<?php if(auth()->check() && auth()->user()->hasRole('superadmin')): ?>
<li class="nav-header">Account</li>

<li class="nav-item">
    <a href="<?php echo e(route('admins.index')); ?>" class="nav-link <?php echo e(Request::is('admins') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-user"></i>
        <p>
            Accounts Admin
        </p>
    </a>
</li>
<?php endif; ?>

<li class="nav-header">Office</li>
<li class="nav-item">
    <a href="<?php echo e(route('companies.index')); ?>" class="nav-link <?php echo e(Request::is('companies') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-building"></i>
        <p>
            Companies
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('departments.index')); ?>" class="nav-link <?php echo e(Request::is('departments') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-archive"></i>
        <p>
            Departments
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('masterSchemas.index')); ?>" class="nav-link <?php echo e(Request::is('masterSchemas') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-database"></i>
        <p>
            Master Schema
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('organizationals.index')); ?>" class="nav-link <?php echo e(Request::is('organizationals') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-certificate"></i>
        <p>
            Organizationals
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('employees.index')); ?>" class="nav-link <?php echo e(Request::is('employees') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Employees
        </p>
    </a>
</li>
<li class="nav-header">List</li>

<li
    class="nav-item 
    <?php echo e(Request::is('schemaSchedules*') ? 'menu-open' : ''); ?>

    <?php echo e(Request::is('shiftSchedules*') ? 'menu-open' : ''); ?>

    <?php echo e(Request::is('schemaLeaves*') ? 'menu-open' : ''); ?>">
    <a href="#"
        class="nav-link 
        <?php echo e(Request::is('schemaSchedules*') ? 'active' : ''); ?>

        <?php echo e(Request::is('shiftSchedules*') ? 'active' : ''); ?>

        <?php echo e(Request::is('schemaLeaves*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-circle"></i>
        <p>
            Schedule
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('schemaSchedules.index')); ?>" class="nav-link <?php echo e(Request::is('schemaSchedules') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-sticky-note"></i>
                <p>
                    Regular
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('shiftSchedules.index')); ?>" class="nav-link <?php echo e(Request::is('shiftSchedules') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-calendar"></i>
                <p>
                    Non Regular
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('schemaLeaves.index')); ?>" class="nav-link <?php echo e(Request::is('schemaLeaves') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-cube"></i>
                <p>
                    Schema Leave
                </p>
            </a>
        </li>
    </ul>
</li>

<?php if(auth()->check() && auth()->user()->hasRole('superadmin')): ?>
<li class="nav-item">
    <a href="<?php echo e(route('salaries.index')); ?>" class="nav-link <?php echo e(Request::is('salaries') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-calculator"></i>
        <p>
            Salaries
        </p>
    </a>
</li>
<?php endif; ?>

<li class="nav-item">
    <a href="<?php echo e(route('attendances.index')); ?>" class="nav-link <?php echo e(Request::is('attendances') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-hand-paper"></i>
        <p>
            Attendances
        </p>
    </a>
</li>

<li class="nav-header">Break</li>

<li class="nav-item">
    <a href="<?php echo e(route('schemaBreaks.index')); ?>" class="nav-link <?php echo e(Request::is('schemaBreaks') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-asterisk"></i>
        <p>
            Schema Breaks
        </p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('submissions.index')); ?>" class="nav-link <?php echo e(Request::is('submissions') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-file-word"></i>
        <p>
            Submissions
        </p>
    </a>
</li>

<li class="nav-header">
    <br>
</li>
<?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/layouts/menu.blade.php ENDPATH**/ ?>