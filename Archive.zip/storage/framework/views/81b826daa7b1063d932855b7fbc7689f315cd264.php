<div class="table-responsive">
    <table class="table" id="example2">
        <thead>
        <tr>
            <th>No</th>
            <?php if(Request::is('salaries/type/company')): ?>
            <th>Company</th>
            <?php endif; ?>
            <?php if(Request::is('salaries/type/organizational')): ?>
            <th>Company</th>
            <th>Organizational</th>
            <?php endif; ?>
            <?php if(Request::is('salaries')): ?>
            <th>Employee</th>
            <?php endif; ?>
            <th>Salary</th>
            
            <th>Info Profit</th>
            <th>From Date</th>
            <th>To Date</th>
            
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php ($count = 1); ?>
        <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salaries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($count++); ?></td>
                <?php if(Request::is('salaries/type/company')): ?>
                <td><?php echo e(App\Models\Company::find($salaries->id_company)->name); ?></td>
                <?php endif; ?>
                <?php if(Request::is('salaries/type/organizational')): ?>
                <td><?php echo e(App\Models\Company::find($salaries->id_company)->name ?? ''); ?></td>
                <td><?php echo e(App\Models\Organizational::find($salaries->id_org)->job_title ?? ''); ?></td>
                <?php endif; ?>
                <?php if(Request::is('salaries')): ?>
                <td><?php echo e(App\Models\Employee::find($salaries->id_employee)->name ?? ''); ?></td>
                <?php endif; ?>
                <td><?php echo e(number_format($salaries->salary, '0', ',', '.')); ?></td>
                
                <td><?php echo e($salaries->info_profit); ?></td>
                <td><?php echo e(date('d M Y', strtotime($salaries->from_date))); ?></td>
                <td><?php echo e(date('d M Y', strtotime($salaries->to_date))); ?></td>
                
                <td width="120">
                    <?php echo Form::open(['route' => ['salaries.destroy', $salaries->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('salaries.show', [$salaries->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('salaries.edit', [$salaries->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/salaries/table.blade.php ENDPATH**/ ?>