<!-- Id Company Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_company', 'Id Company:'); ?>

    <?php echo Form::number('id_company', null, ['class' => 'form-control']); ?>

</div>

<!-- Id Org Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_org', 'Id Org:'); ?>

    <?php echo Form::number('id_org', null, ['class' => 'form-control']); ?>

</div>

<!-- Id Employee Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_employee', 'Id Employee:'); ?>

    <?php echo Form::number('id_employee', null, ['class' => 'form-control']); ?>

</div>

<!-- Salary Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('salary', 'Salary:'); ?>

    <?php echo Form::number('salary', null, ['class' => 'form-control']); ?>

</div>

<!-- Status Profit Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status_profit', 'Status Profit:'); ?>

    <?php echo Form::text('status_profit', null, ['class' => 'form-control','maxlength' => 1,'maxlength' => 1]); ?>

</div>

<!-- Info Profit Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('info_profit', 'Info Profit:'); ?>

    <?php echo Form::text('info_profit', null, ['class' => 'form-control','maxlength' => 64,'maxlength' => 64]); ?>

</div>

<!-- From Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('from_date', 'From Date:'); ?>

    <?php echo Form::text('from_date', null, ['class' => 'form-control','id'=>'from_date']); ?>

</div>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('#from_date').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- To Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('to_date', 'To Date:'); ?>

    <?php echo Form::text('to_date', null, ['class' => 'form-control','id'=>'to_date']); ?>

</div>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('#to_date').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- Id Employee Approv Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('id_employee_approv', 'Id Employee Approv:'); ?>

    <?php echo Form::number('id_employee_approv', null, ['class' => 'form-control']); ?>

</div><?php /**PATH /Users/akil/Documents/Project/hasamitra/resources/views/salaries/fields.blade.php ENDPATH**/ ?>